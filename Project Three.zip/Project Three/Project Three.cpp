/*
   Name: Prithvi Ghale
   Date: 17 October 2024
*/

#include <iostream>
#include <fstream>
#include <map> // Here I include map to store item frequencies
#include <string>
#include <limits> // For input validation

using namespace std;

class ItemTracker {
private:
    map<string, int> itemFrequency; // Here I use a map to store items and their frequencies

public:
    // This function reads items from the file and stores them in the map
    void readFile(const string& fileName);

    // This function is used to search for an item and display its frequency
    void searchItem(const string& item);

    // This function prints all the items and how many times each was purchased
    void printFrequencies();

    // This function prints a histogram with asterisks to represent the frequency of each item
    void printHistogram();

    // This function creates a backup file with item frequencies
    void createBackupFile(const string& fileName);
};

// This function reads the input file and adds the items to the map
void ItemTracker::readFile(const string& fileName) {
    ifstream inputFile(fileName); // Here, I open the file
    string item;

    if (!inputFile) { // If the file cannot be opened, I print an error message
        cout << "Error: Cannot open input file.\n";
        return;
    }

    // Here I read each item from the file and increase its count in the map
    while (inputFile >> item) {
        itemFrequency[item]++; // This line will increment the item's frequency
    }
    inputFile.close(); // This line closes the input file
}

// This function searches for a specific item and prints its frequency
void ItemTracker::searchItem(const string& searchItem) {
    // Here I check if the item exists in the map
    if (itemFrequency.find(searchItem) != itemFrequency.end()) {
        // If found, I print the item's frequency
        cout << searchItem << ": " << itemFrequency[searchItem] << " purchases\n";
    }
    else {
        // If the item isn't found, I print a message saying it wasn't found
        cout << "Item not found.\n";
    }
}

// This function prints all the items and their frequencies
void ItemTracker::printFrequencies() {
    // Here I loop through the map and print each item with its frequency
    for (const auto& pair : itemFrequency) {
        cout << pair.first << ": " << pair.second << " purchases\n"; // This line prints the item and frequency
    }
}

// This function prints a histogram of items using asterisks
void ItemTracker::printHistogram() {
    // I loop through the map and print asterisks for each item's frequency
    for (const auto& pair : itemFrequency) {
        cout << pair.first << ": " << string(pair.second, '*') << "\n"; // Here, asterisks represent the frequency
    }
}

// This function creates a backup file that stores all item frequencies
void ItemTracker::createBackupFile(const string& fileName) {
    ofstream backupFile(fileName); // Here I open the backup file

    if (!backupFile) { // If the backup file can't be opened, I print an error message
        cout << "Error: Cannot open backup file.\n";
        return;
    }

    // I write each item and its frequency to the backup file
    for (const auto& pair : itemFrequency) {
        backupFile << pair.first << " " << pair.second << "\n"; // This line writes the item and frequency to the file
    }
    backupFile.close(); // This line closes the backup file
}

int main() {
    ItemTracker tracker; // I create an instance of the ItemTracker class
    int choice = 0; // Variable to store the user's menu choice
    string item; // Variable to store the user's input when searching for an item

    // Here, I read the input file to populate the map with items and their frequencies
    tracker.readFile("CS210_Project_Three_Input_File.txt");

    // This is the menu loop
    while (true) {
        // Here I print the menu options
        cout << "\nMenu Options:\n";
        cout << "1. Search for an item\n";
        cout << "2. Print all item frequencies\n";
        cout << "3. Print histogram of items\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";

        // Input validation for the menu choice
        if (!(cin >> choice)) { // If the input is not a number, I handle it here
            cout << "Invalid input. Please enter a number between 1 and 4.\n";
            cin.clear(); // This clears the error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // This ignores the invalid input
            continue; // Here I go back to the start of the loop
        }

        // I check if the choice is out of range (not between 1 and 4)
        if (choice < 1 || choice > 4) {
            cout << "Invalid choice. Please enter a number between 1 and 4.\n";
            continue; // Here I go back to the start of the loop if the choice is invalid
        }

        // I perform the appropriate action based on the user's choice
        switch (choice) {
        case 1:
            // Here I ask the user to enter an item to search for
            cout << "Enter item name: ";
            cin >> item;
            tracker.searchItem(item); // This calls the searchItem function to find the item's frequency
            break;
        case 2:
            // This will print all items and their frequencies
            tracker.printFrequencies();
            break;
        case 3:
            // This will print the histogram using asterisks
            tracker.printHistogram();
            break;
        case 4:
            // This message is displayed when the user chooses to exit
            cout << "Exiting program...\n";
            // Here I create the backup file before exiting
            tracker.createBackupFile("frequency.dat");
            return 0; // Exit the program
        }
    }
}
